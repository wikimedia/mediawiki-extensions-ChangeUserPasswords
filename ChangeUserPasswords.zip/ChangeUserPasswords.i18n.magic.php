<?php
/**
 * Magic words of the {{ cookiecutter.repo_name }} extension
 *
 * @file
 * @ingroup Extensions
 */

$magicWords = array();

/** English (English) */
$magicWords['en'] = array(
   'something' => array( 0, 'something' ),
);
