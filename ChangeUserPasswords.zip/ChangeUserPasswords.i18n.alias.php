
<?php
/**
 * Aliases for special pages of the {{ cookiecutter.repo_name }} extension
 *
 * @file
 * @ingroup Extensions
 */

$specialPageAliases = [];

/** English (English) */
$specialPageAliases['en'] = [
	'ChangeUserPasswords' => [ 'ChangeUserPasswords' , 'Change User Passwords'],
];

